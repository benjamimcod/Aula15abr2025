//array comum

let numbers = [1, 2, 3, 4]
console.log(numbers[1])

//Array bidimensional - Matrizes
/*
salvamento de dados
Inteligencias artificial (comp.Visional)
Des. Jogos
Waze
*/

let matriz = [
    [1, 2, 3], //linha 0
    [1, 1, 23] //linha 1
]
console.log(matriz[1][2])
        //matriz[linha][coluna]

//Laço de repetição - FOR(para)
//for(inicia, condicao, incremento){corpo do código}
for(let i = 0; i < matriz.length; i++){
    let linha = ''
    for(let j = 0; j < matriz[i].length; j++){
        linha += matriz[i][j] + ' ';
    }
    console.log(linha)
}

/*
linha = ''
linha += 1 + '' -> '1 '
linha += 2 + '' -> '1 2 '
linha += 3 + '' -> '1 2 3 '
*/


