let mat = [
    [1, 2, 3]
    [4, 5, 6]
    [7, 8, 9]
]
for(let i = 0; i < matriz.length; i++){
    let linha = ''
    for(let j = 0; j < matriz[i].length; j++){
        linha += matriz[i][j] + ' ';
    }
    console.log(linha.trim())
}
console.log(mat)