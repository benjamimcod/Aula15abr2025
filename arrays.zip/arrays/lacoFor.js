//Laço de repetição

//for(para)
// i++ é a mesma coisa que i=1+1
//for(inicio, condicao, incremento){corpo}

for(let num = 0; num < 10; num++){
    console.log(num)
}
